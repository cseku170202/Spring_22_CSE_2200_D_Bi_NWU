enum ProductFilter {
  all,
  latest,
  brand,
  mostPopular,
}
