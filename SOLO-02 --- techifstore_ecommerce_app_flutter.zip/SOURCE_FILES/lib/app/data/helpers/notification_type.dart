enum NotificationType { release, payment, update }
