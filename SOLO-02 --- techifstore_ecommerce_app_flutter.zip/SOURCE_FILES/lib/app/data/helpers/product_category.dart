enum ProductCategory { all, sofa, chair, table, lamp,bed }
