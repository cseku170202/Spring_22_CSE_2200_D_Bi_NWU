package com.example.ngamar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
